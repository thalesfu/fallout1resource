---
title: Boy 男孩（ID 1406）
aliases:
  - 旧城区 - Boy 男孩（ID 1406）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 1406
prototype_id: 42
map_tile: 21305
resource_script: CHILD.INT
---

# Boy 男孩

## 身份

旧城区的一名男孩。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `1406` |
| 人物原型 ID | `42` |
| 地图格 | `21305` |
| 脚本 | `CHILD.INT` |

