---
title: Peasant 农民（ID 1478）
aliases:
  - 旧城区 - Peasant 农民（ID 1478）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 1478
prototype_id: 170
map_tile: 22086
resource_script: GENSKAG.INT
---

# Peasant 农民

## 身份

旧城区的一名农民。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `1478` |
| 人物原型 ID | `170` |
| 地图格 | `22086` |
| 脚本 | `GENSKAG.INT` |

