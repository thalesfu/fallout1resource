---
title: Chad 查德（ID 790）
aliases:
  - Hub 哈勃城 - Chad 查德
  - Chad 查德（万斯的守卫）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 790
prototype_id: 246
map_tile: 16857
---

# Chad 查德

## 身份

[[Hub 哈勃城 - Vance 万斯（ID 654）|Vance 万斯]]的守卫之一。万斯在对话中明确说他的两名守卫是 Justin 和 Chad；人物原型 `246` 将本对象确定为 Chad。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `790` |
| 人物原型 ID | `246` |
| 地图格 | `16857` |
| 脚本 | 无独立人物脚本 |

