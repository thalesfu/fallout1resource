---
title: Junkie 瘾君子（ID 517）
aliases:
  - 旧城区 - Junkie 瘾君子（ID 517）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 517
prototype_id: 4
map_tile: 15451
resource_script: JUNKIE.INT
---

# Junkie 瘾君子

## 身份

旧城区的一名瘾君子，位于万斯住处附近。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `517` |
| 人物原型 ID | `4` |
| 地图格 | `15451` |
| 脚本 | `JUNKIE.INT` |

