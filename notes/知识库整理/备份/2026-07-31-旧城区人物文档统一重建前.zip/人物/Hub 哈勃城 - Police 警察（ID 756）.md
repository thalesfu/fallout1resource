---
title: Police 警察（ID 756）
aliases:
  - 旧城区 - Police 警察（ID 756）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 756
prototype_id: 132
map_tile: 16525
resource_script: GENCOP.INT
---

# Police 警察

## 身份

旧城区的一名哈勃城警察。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `756` |
| 人物原型 ID | `132` |
| 地图格 | `16525` |
| 脚本 | `GENCOP.INT` |

