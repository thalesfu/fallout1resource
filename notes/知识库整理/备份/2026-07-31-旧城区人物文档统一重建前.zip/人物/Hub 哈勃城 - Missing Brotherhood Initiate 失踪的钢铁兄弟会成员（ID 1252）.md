---
title: Missing Brotherhood Initiate 失踪的钢铁兄弟会成员（ID 1252）
aliases:
  - 旧城区 - Missing Brotherhood Initiate 失踪的钢铁兄弟会成员（ID 1252）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 1252
prototype_id: 174
map_tile: 20344
resource_script: MISSBRO.INT
---

# Missing Brotherhood Initiate 失踪的钢铁兄弟会成员

## 身份

被旧城区绑匪关押的钢铁兄弟会成员。获救后会要求玩家向塔鲁斯报平安。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `1252` |
| 人物原型 ID | `174` |
| 地图格 | `20344` |
| 脚本 | `MISSBRO.INT` |

