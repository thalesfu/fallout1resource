---
title: Lowly Peasant 贫民（ID 1239）
aliases:
  - 旧城区 - Lowly Peasant 贫民（ID 1239）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 1239
prototype_id: 169
map_tile: 20286
resource_script: GENSKAG.INT
---

# Lowly Peasant 贫民

## 身份

旧城区的一名贫民。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `1239` |
| 人物原型 ID | `169` |
| 地图格 | `20286` |
| 脚本 | `GENSKAG.INT` |

