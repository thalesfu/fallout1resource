---
title: Peasant 农民（ID 853）
aliases:
  - 旧城区 - Peasant 农民（ID 853）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 853
prototype_id: 170
map_tile: 17519
resource_script: GENSKAG.INT
---

# Peasant 农民

## 身份

旧城区的一名农民。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `853` |
| 人物原型 ID | `170` |
| 地图格 | `17519` |
| 脚本 | `GENSKAG.INT` |

