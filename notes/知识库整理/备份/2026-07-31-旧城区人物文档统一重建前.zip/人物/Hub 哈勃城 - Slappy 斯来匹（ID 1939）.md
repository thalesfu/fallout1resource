---
title: Slappy 斯来匹
aliases:
  - Hub 哈勃城 - Slappy 斯来匹
  - Hub 哈勃城 - 斯来匹
  - 斯来匹
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 1939
prototype_id: 86
map_tile: 25131
resource_script: SLAPPY.INT
---

# 形象
![[Pasted image 20260322214145.png]]
# 对话
哦哦哦，漂亮，漂亮东西。为什么是月亮？
## 1 你在这做什么？
做，我，做，然后你做，然后我们都做。
### 1.1 不是，你是干什么的
我做这个，然后我做那个。你看见哈罗德了？哈罗德很滑稽，他的头发掉光了，随风而去了。飞了……风，风。
#### 1.1.1 随便
### 1.2 你是个疯子
## 2 你有什么问题？
