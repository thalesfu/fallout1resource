---
title: Justin 贾斯廷（ID 541）
aliases:
  - Hub 哈勃城 - Justin 贾斯廷
  - Justin 贾斯廷（万斯的守卫）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 541
prototype_id: 238
map_tile: 15656
---

# Justin 贾斯廷

## 身份

[[Hub 哈勃城 - Vance 万斯（ID 654）|Vance 万斯]]的守卫之一。万斯在对话中明确说他的两名守卫是 Justin 和 Chad；人物原型 `238` 将本对象确定为 Justin。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `541` |
| 人物原型 ID | `238` |
| 地图格 | `15656` |
| 脚本 | 无独立人物脚本 |

