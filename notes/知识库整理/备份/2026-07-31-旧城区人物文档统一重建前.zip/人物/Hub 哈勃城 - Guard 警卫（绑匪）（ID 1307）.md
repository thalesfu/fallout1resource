---
title: Guard 警卫（绑匪）（ID 1307）
aliases:
  - 旧城区 - Guard 警卫（绑匪）（ID 1307）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 1307
prototype_id: 205
map_tile: 20737
resource_script: HUBCAPTR.INT
---

# Guard 警卫（绑匪）

## 身份

旧城区绑匪团伙的一名警卫，负责看守失踪的钢铁兄弟会成员。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `1307` |
| 人物原型 ID | `205` |
| 地图格 | `20737` |
| 脚本 | `HUBCAPTR.INT` |

