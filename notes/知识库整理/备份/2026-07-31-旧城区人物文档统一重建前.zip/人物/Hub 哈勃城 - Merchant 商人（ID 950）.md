---
title: Merchant 商人（ID 950）
aliases:
  - 旧城区 - Merchant 商人（ID 950）
tags:
  - 辐射1
  - 人物
  - 哈勃城
  - 旧城区
map: HUBOLDTN
elevation: 0
map_object_id: 950
prototype_id: 195
map_tile: 18317
resource_script: GENSKAG.INT
---

# Merchant 商人

## 身份

旧城区的一名商人。

## 地图信息

| 属性 | 值 |
|---|---|
| 出现地点 | [[Old Town 旧城区\|旧城区]] |
| 资源地图 | `HUBOLDTN.MAP` |
| 楼层 | 0 |
| 地图对象 ID | `950` |
| 人物原型 ID | `195` |
| 地图格 | `18317` |
| 脚本 | `GENSKAG.INT` |

