---
aliases:
  - Khans 可汗帮 - Garl 伽尔
  - Raiders 歹徒 - Khans 可汗帮 - Garl 伽尔
  - Garl 伽尔
  - “死亡之手”伽尔
---

# 名字

Garl Death-Hand 死亡之手伽尔

# 身份

可汗帮首领。

# 行为

**赛思**：一直想侵占沙荫镇。

# 评价

**伊恩**：伽尔是一个笨蛋——他认为自己能带着那些歹徒征服整个世界。

> [!note] 资源依据
> `GARL.MSG` 中 Garl 自称“Garl Death-Hand”，生效汉化为“死亡之手伽尔”；`RAIDGRD.MSG` 和 `DIANA.MSG` 也使用该完整称号式姓名。
