---
aliases:
  - JunkTown 迦克镇 - 门卫
  - Junktown 迦克镇 - 门卫
  - 迦克镇门卫
---

# 形象
![[a9b48e7d7ae641883d277340a155385a_MD5.png]]
# 位置
![[738d38e2066dc7914bda5d73f558c100_MD5.png]]
# 物品
![[ed743231f87cc07fe8685ff169fbaf87_MD5.png]]
