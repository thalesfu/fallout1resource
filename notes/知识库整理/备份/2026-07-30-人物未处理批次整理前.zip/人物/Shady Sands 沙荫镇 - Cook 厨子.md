---
aliases:
  - Shady 沙荫镇 - 厨师
  - 沙荫镇厨师
  - 厨师
---

# 形象
![[7418f511d4a8417817ddade099d95fd5_MD5.png]]
# 物品
![[9a38a0c786d4617d26455c7936a5d451_MD5.png]]
