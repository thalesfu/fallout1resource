---
aliases:
  - Shady 沙荫镇 - Razlo拉斯洛（医生）
  - Razlo 拉斯洛（医生）
---

# 名字
Razlo 拉斯洛
# 形象
![[2d92e6270798308bbfbf3546b8ccd005_MD5.png]]
# 物品
![[57f2919fce807686a8edf8b69e6dde85_MD5.png]]
# 职业
医生
# 历史
**拉斯洛**：莫彼得德医生教过他
