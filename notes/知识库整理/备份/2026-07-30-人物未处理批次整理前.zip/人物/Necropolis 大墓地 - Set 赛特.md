---
aliases:
  - Set 赛特
---

# 名字

Set 赛特

# 身份

大墓地的头目。

> [!note] 资源依据
> `SET.MSG` 的相遇描述为“You see Set, the Leader of Necropolis.”，生效汉化为“你看见赛特，大墓地的头目。”
