---
aliases:
  - Shady 沙荫镇 - Tandi坦蒂（镇长女儿）
  - Tandi 坦蒂（镇长女儿）
---

# 名字
Tandi 坦蒂
# 职业
镇长女儿
# 形象
![[5428282ae41f49be2c415cb24f173f31_MD5.png]]
![[b332f6637d2e78807e03ea64656444b0_MD5.png]]
# 物品
![[2df6c1c2f745e00f999a61b9d1511e40_MD5.png]]
# 实例
**赛思**：还需要锻炼自己
# 兴趣
**坦蒂**：tandi想去见识见识哈勃城
