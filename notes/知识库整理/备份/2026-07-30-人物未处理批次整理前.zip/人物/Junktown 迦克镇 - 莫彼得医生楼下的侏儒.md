![06 游戏/辐射1/日记/attachments/d76d98571904068192621293b5e8de39_MD5.png](app://214442ff0acda0734ad7effc77abe31ae741/Users/thalesfu/Library/Mobile%20Documents/iCloud~md~obsidian/Documents/Thales/06%20%E6%B8%B8%E6%88%8F/%E8%BE%90%E5%B0%841/%E6%97%A5%E8%AE%B0/attachments/d76d98571904068192621293b5e8de39_MD5.png?1762840102606)

这个侏儒有点笨，
他负责分割人尸
他说这些人肉送到哈勃城去，蜥蜴商人哈勃会去卖会，会吃。莫彼得医生有这一带最好的人尸