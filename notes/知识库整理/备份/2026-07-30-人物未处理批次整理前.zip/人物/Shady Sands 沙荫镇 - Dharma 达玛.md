---
aliases:
  - Dharma 达玛（先知）
  - Dharma 先知达玛
  - 先知达玛
---

# 名字
Dharma 达玛
# 职业
先知
# 性格
**亚拉德什** 一个伟大而虔诚的人
