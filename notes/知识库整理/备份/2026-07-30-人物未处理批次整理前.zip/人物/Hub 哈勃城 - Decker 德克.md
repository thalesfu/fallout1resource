# 形象
![[Pasted image 20260321161226.png]]
# 询问
Decker-德克
Underground-地下团体
Maltese-马耳他
Thieves-小偷
Justin-贾斯汀
Harold-哈罗德
Merchants-商人
Daren-达伦
Crimson-深红
Demetre-戴米德
Far-远行
Butch-布奇
Beth-贝斯
Missing-失踪
Market-市场
Claw-爪
Town-城镇
Heights-高地
Cathedral-大教堂
Morpheus-墨菲斯
Jain-简恩
Master-主教
Store-商店
All-In-One-百货店
Falcon-猎鹰
Nightclub-夜总会
Greene-格林
Hightower-海托
Caravans-商队
Romara-罗玛拉
Go-远行
Trader-远行商会
Harris-哈里斯
Death-死亡
Deathclaw-死亡爪
Old-老的
Oldtown-老城区
Children-教徒
All-百货
# 对话1
那么，你在找活干。运气不赖，我正有事要找人做。啊，我失礼了，你叫什么名字？
## 1 我是Thales
呃，客套话咱就不说了。你想听听工作的事吗？
### 1.1 那就是我在这的原因
背景：有个商人……怎么形容呢……他和我们的地下组织合作的不好。
#### 1.1.1 工作呢？
很简单，找到那个商人和他妻子并了结他们。
##### 1.1.1.1 你是说杀了他们？
##### 1.1.1.2 干着活儿多少钱？
这是标准的行情，事前500块，事成后再付2500，你肯做吗？
###### 1.1.1.2.1 不，谢谢
###### 1.1.1.2.2 是的，我做
很好，这商人住在高地，在商业街和桑德大道上。在你出去时会先付一部分报酬给你。
##### 1.1.1.3 我不能这么做！
### 1.2 没啥兴趣
## 2 我的名字关你什么事？