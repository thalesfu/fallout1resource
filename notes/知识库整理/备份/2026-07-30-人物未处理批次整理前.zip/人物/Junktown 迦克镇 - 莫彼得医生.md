# 形象
![06 游戏/辐射1/日记/attachments/e459741d7b4a26a97aec9353af6856a4_MD5.png](app://214442ff0acda0734ad7effc77abe31ae741/Users/thalesfu/Library/Mobile%20Documents/iCloud~md~obsidian/Documents/Thales/06%20%E6%B8%B8%E6%88%8F/%E8%BE%90%E5%B0%841/%E6%97%A5%E8%AE%B0/attachments/e459741d7b4a26a97aec9353af6856a4_MD5.png?1761747299247)
# 位置
![[d3130b1e6f4b491b8468115988329c34_MD5.png]]
# 事件
彼得医生和他诊所下面的侏儒贩卖人肉