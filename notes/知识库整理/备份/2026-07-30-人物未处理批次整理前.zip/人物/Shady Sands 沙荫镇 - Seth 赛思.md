---
aliases:
  - Shady 沙荫镇 - Seth 赛思（门卫队长）
  - Seth 赛思（门卫队长）
---

# 名字
Seth 赛思
# 形象
![[b9d9f6309a96160b4e2fb9acaf05f9b4_MD5.png]]
# 物品
![[7397ce6d8f661e9e7c1fce2a7ce384e3_MD5.png]]
# 职业
门卫队长
# 评价
**伊恩**：非常勇猛的展示，会独自去洞穴解决一些辐射蝎，但是它们不就又会卷土重来，让他应接不暇
**坦蒂**：亚拉德什撮合过seth和tandi，但是tandi不喜欢
