# 形象
![[1b175fe03d53f620fe193cd817ecca06_MD5.png]]
# 位置
![[292d98ece12c3b20bc999fb3cd70e4c2_MD5.png]]
# 职业
吉斯莫的保镖